has exported   import cache
  cache        compile
    ^            ^
    |            |
    X  ->  Y  -> Z